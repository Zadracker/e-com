heroku logs --tail --app my_app_name_in_herouku_site
                         (edit this above aprt depend on your need)